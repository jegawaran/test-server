
__version_info__ = ('6', '14', '6')
__version__ = '.'.join(__version_info__)
